// =============================================================================
// cad_primitives.dart
//
// Standalone 2D and 3D geometric primitives for Sheet Metal Studio.
// Designed with zero dependencies on external app code so this entire module
// can be copied into any standalone Flutter/Dart application.
// =============================================================================

import 'dart:math' as math;

import 'package:flutter/material.dart';

export 'cad_geometry.dart' show CadArc2D;
export 'cad_material_preset.dart';
export 'paint_coat_specification.dart';

import 'cad_material_preset.dart';

/// 2D Coordinate Point (in mm)
@immutable
class CadPoint2D {
  final double x;
  final double y;

  const CadPoint2D(this.x, this.y);

  CadPoint2D operator +(CadPoint2D other) => CadPoint2D(x + other.x, y + other.y);
  CadPoint2D operator -(CadPoint2D other) => CadPoint2D(x - other.x, y - other.y);
  CadPoint2D operator *(double scale) => CadPoint2D(x * scale, y * scale);
  CadPoint2D operator /(double divisor) => CadPoint2D(x / divisor, y / divisor);

  double get length => math.sqrt(x * x + y * y);

  double distanceTo(CadPoint2D other) {
    final dx = x - other.x;
    final dy = y - other.y;
    return math.sqrt(dx * dx + dy * dy);
  }

  Offset toOffset() => Offset(x, y);

  Map<String, dynamic> toJson() => {'x': x, 'y': y};
  factory CadPoint2D.fromJson(Map<String, dynamic> json) => CadPoint2D((json['x'] as num).toDouble(), (json['y'] as num).toDouble());

  @override
  String toString() => 'CadPoint2D($x, $y)';

  @override
  bool operator ==(Object other) => identical(this, other) || other is CadPoint2D && (x - other.x).abs() < 1e-4 && (y - other.y).abs() < 1e-4;

  @override
  int get hashCode => Object.hash(x.round(), y.round());
}

/// 3D Coordinate Point (in mm)
@immutable
class CadPoint3D {
  final double x;
  final double y;
  final double z;

  const CadPoint3D(this.x, this.y, this.z);

  CadPoint3D operator +(CadPoint3D other) => CadPoint3D(x + other.x, y + other.y, z + other.z);
  CadPoint3D operator -(CadPoint3D other) => CadPoint3D(x - other.x, y - other.y, z - other.z);
  CadPoint3D operator *(double scale) => CadPoint3D(x * scale, y * scale, z * scale);
  CadPoint3D operator /(double divisor) => CadPoint3D(x / divisor, y / divisor, z / divisor);

  double dot(CadPoint3D other) => x * other.x + y * other.y + z * other.z;

  CadPoint3D cross(CadPoint3D other) => CadPoint3D(y * other.z - z * other.y, z * other.x - x * other.z, x * other.y - y * other.x);

  double get length => math.sqrt(x * x + y * y + z * z);
  double distanceTo(CadPoint3D other) => (this - other).length;

  CadPoint3D normalized() {
    final len = length;
    if (len < 1e-6) return const CadPoint3D(0, 0, 1);
    return CadPoint3D(x / len, y / len, z / len);
  }

  Map<String, dynamic> toJson() => {'x': x, 'y': y, 'z': z};
  factory CadPoint3D.fromJson(Map<String, dynamic> json) =>
      CadPoint3D((json['x'] as num).toDouble(), (json['y'] as num).toDouble(), (json['z'] as num).toDouble());

  @override
  String toString() => 'CadPoint3D($x, $y, $z)';

  @override
  bool operator ==(Object other) =>
      identical(this, other) || other is CadPoint3D && (x - other.x).abs() < 1e-4 && (y - other.y).abs() < 1e-4 && (z - other.z).abs() < 1e-4;

  @override
  int get hashCode => Object.hash(x.round(), y.round(), z.round());
}

/// 3D Polygon Face for Shaded Rendering
class CadFoldedPolygon3D {
  final String faceId;
  final List<CadPoint3D> vertices;
  final CadPoint3D normal;
  final Color color;
  final bool drawWireframe;
  final List<List<CadPoint3D>> holes;
  final List<String> holePunchIds;
  final List<List<CadPoint3D>> cutSegments;
  final List<List<CadPoint3D>> boundaryLines;
  final List<List<CadPoint3D>> tangentLines;

  const CadFoldedPolygon3D({
    required this.faceId,
    required this.vertices,
    required this.normal,
    this.color = const Color(0xFFB0BEC5),
    this.drawWireframe = true,
    this.holes = const [],
    this.holePunchIds = const [],
    this.cutSegments = const [],
    this.boundaryLines = const [],
    this.tangentLines = const [],
  });

  CadFoldedPolygon3D copyWith({
    String? faceId,
    List<CadPoint3D>? vertices,
    CadPoint3D? normal,
    Color? color,
    bool? drawWireframe,
    List<List<CadPoint3D>>? holes,
    List<String>? holePunchIds,
    List<List<CadPoint3D>>? cutSegments,
    List<List<CadPoint3D>>? boundaryLines,
    List<List<CadPoint3D>>? tangentLines,
  }) {
    return CadFoldedPolygon3D(
      faceId: faceId ?? this.faceId,
      vertices: vertices ?? this.vertices,
      normal: normal ?? this.normal,
      color: color ?? this.color,
      drawWireframe: drawWireframe ?? this.drawWireframe,
      holes: holes ?? this.holes,
      holePunchIds: holePunchIds ?? this.holePunchIds,
      cutSegments: cutSegments ?? this.cutSegments,
      boundaryLines: boundaryLines ?? this.boundaryLines,
      tangentLines: tangentLines ?? this.tangentLines,
    );
  }
}

/// 2D Line Segment (used for Laser Cut Lines, Slits, Partition Edges)
@immutable
class CadLineSegment {
  final String id;
  final CadPoint2D p1;
  final CadPoint2D p2;
  final String layer;
  final bool showLabel;

  const CadLineSegment({required this.id, required this.p1, required this.p2, this.layer = 'CUT', this.showLabel = true});

  double get x1 => p1.x;
  double get y1 => p1.y;
  double get x2 => p2.x;
  double get y2 => p2.y;
  bool get isVisible => true;

  double get length => p1.distanceTo(p2);
  double get angleRad => math.atan2(p2.y - p1.y, p2.x - p1.x);
  double get angleDeg => angleRad * 180.0 / math.pi;
  CadPoint2D get midpoint => CadPoint2D((p1.x + p2.x) / 2.0, (p1.y + p2.y) / 2.0);

  CadLineSegment copyWith({String? id, CadPoint2D? p1, CadPoint2D? p2, String? layer, bool? showLabel}) {
    return CadLineSegment(id: id ?? this.id, p1: p1 ?? this.p1, p2: p2 ?? this.p2, layer: layer ?? this.layer, showLabel: showLabel ?? this.showLabel);
  }

  Map<String, dynamic> toJson() => {'id': id, 'p1': p1.toJson(), 'p2': p2.toJson(), 'layer': layer, 'showLabel': showLabel};

  factory CadLineSegment.fromJson(Map<String, dynamic> json) => CadLineSegment(
    id: json['id'] as String? ?? 'C1',
    p1: CadPoint2D.fromJson(json['p1'] as Map<String, dynamic>),
    p2: CadPoint2D.fromJson(json['p2'] as Map<String, dynamic>),
    layer: json['layer'] as String? ?? 'CUT',
    showLabel: json['showLabel'] as bool? ?? true,
  );

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is CadLineSegment &&
          runtimeType == other.runtimeType &&
          id == other.id &&
          p1 == other.p1 &&
          p2 == other.p2 &&
          layer == other.layer &&
          showLabel == other.showLabel;

  @override
  int get hashCode => Object.hash(id, p1, p2, layer, showLabel);

  @override
  String toString() => 'CadLineSegment($id, p1: $p1, p2: $p2, layer: $layer, showLabel: $showLabel)';
}

/// Visual shading and illustration styles for CAD 3D rendering.
enum CadShadingStyle {
  realisticPbr(
    'Industrial PBR Metal',
    'Physically-based metallic shading with realistic specular highlights and shadows.',
  ),
  celShaded2D(
    '2D Anime / Drawn Illustration',
    'Non-photorealistic cel shading with quantized light bands and crisp inked outlines, mimicking 2D animation style.',
  ),
  technicalBlueprint(
    'Technical Blueprint',
    'Crisp blueprint drawing style with cool technical tint and highlighted boundary features.',
  );

  final String label;
  final String description;
  const CadShadingStyle(this.label, this.description);
}

/// Anti-aliasing detail levels and resolution supersampling factors.
enum AntiAliasingQuality {
  off('Off', 1.0),
  standard('Standard (MSAA)', 1.0),
  high('High (1.5x)', 1.5),
  ultra('Ultra (2x SSAA)', 2.0),
  extreme('Extreme (3x SSAA)', 3.0);

  final String label;
  final double pixelRatioScale;
  const AntiAliasingQuality(this.label, this.pixelRatioScale);
}

/// CAD Surface & Edge Render Modes matching Onshape View Context Menu.
enum OnshapeRenderMode {
  shadedWithEdges('Shaded with edges'),
  shadedWithoutEdges('Shaded without edges'),
  unshaded('Unshaded'),
  translucent('Translucent');

  final String label;
  const OnshapeRenderMode(this.label);
}

/// Mode for rendering tangent edges (fillet transitions) on CAD parts.
enum OnshapeTangentEdgeMode {
  visible('Tangent edges visible'),
  phantom('Tangent edges phantom'),
  removed('Tangent edges removed');

  final String label;
  const OnshapeTangentEdgeMode(this.label);
}

/// Active 3D CAD rendering engine backend for TruFold Studio.
enum Cad3dEngineMode {
  flutterGpu(
    'Flutter GPU (Scene)',
    'Hardware-accelerated 120 FPS B-Rep CustomPaint + flutter_gpu (Impeller) renderer.',
  );

  final String label;
  final String description;
  const Cad3dEngineMode(this.label, this.description);
}

/// Preserves independent 3D camera pan, zoom, orbit distance, and angles across multiple open tabs.
class Cad3dCameraState {
  final double azimuthDeg;
  final double elevationDeg;
  final double zoom;
  final Offset pan;
  final double orbitDistance;
  final CadPoint3D orbitTarget;
  final bool isInitialized;

  const Cad3dCameraState({
    this.azimuthDeg = 45.0,
    this.elevationDeg = 35.264,
    this.zoom = 1.0,
    this.pan = Offset.zero,
    this.orbitDistance = 350.0,
    this.orbitTarget = const CadPoint3D(0, 0, 0),
    this.isInitialized = false,
  });

  double get panX => pan.dx;
  double get panY => pan.dy;

  Map<String, dynamic> toJson() => {
        'azimuthDeg': azimuthDeg,
        'elevationDeg': elevationDeg,
        'zoom': zoom,
        'panX': pan.dx,
        'panY': pan.dy,
        'orbitDistance': orbitDistance,
        'orbitTargetX': orbitTarget.x,
        'orbitTargetY': orbitTarget.y,
        'orbitTargetZ': orbitTarget.z,
        'isInitialized': isInitialized,
      };

  factory Cad3dCameraState.fromJson(Map<String, dynamic> json) {
    return Cad3dCameraState(
      azimuthDeg: (json['azimuthDeg'] as num?)?.toDouble() ?? 45.0,
      elevationDeg: (json['elevationDeg'] as num?)?.toDouble() ?? 35.264,
      zoom: (json['zoom'] as num?)?.toDouble() ?? 1.0,
      pan: Offset(
        (json['panX'] as num?)?.toDouble() ?? 0.0,
        (json['panY'] as num?)?.toDouble() ?? 0.0,
      ),
      orbitDistance: (json['orbitDistance'] as num?)?.toDouble() ?? 350.0,
      orbitTarget: CadPoint3D(
        (json['orbitTargetX'] as num?)?.toDouble() ?? 0.0,
        (json['orbitTargetY'] as num?)?.toDouble() ?? 0.0,
        (json['orbitTargetZ'] as num?)?.toDouble() ?? 0.0,
      ),
      isInitialized: json['isInitialized'] as bool? ?? false,
    );
  }
}

enum CadLightingPreset {
  onshapeStudio('Onshape Studio (Cool/Warm)'),
  engineeringCrisp('Engineering High-Contrast'),
  clayPresentation('Soft Clay / Cavity Mode'),
  metallicShowroom('Anodized Showroom');

  final String label;
  const CadLightingPreset(this.label);
}

/// Onshape-compatible 3D Graphics Preferences.
/// Configures viewport lighting/FOV, shaded body surface properties, and phantom edge lines.
class OnshapeGraphicsPreferences {
  // Viewport Settings
  final double ambientOcclusion; // 0% to 100%, default 65%
  final double fieldOfView; // 15 deg to 90 deg, default 46 deg
  final AntiAliasingQuality antiAliasingQuality; // Viewport anti-aliasing & SSAA level

  // Shaded Bodies Settings
  final double lineWidth; // 0.5 px to 5.0 px, default 1.35 px
  final double shininess; // 0% to 100%, default 68% (as seen in Onshape SS3)
  final Color specularColor; // default 0xFFFFFFFF (crisp white specular glare)
  final Color sectionInterferenceColor; // default 0xFF4CAF50

  // Phantom Edges Settings
  final double phantomTangentEdgeWidth; // 0.5 px to 4.0 px, default 0.8 px
  final Color phantomTangentEdgeColor; // default 0xFF212121
  final OnshapeTangentEdgeMode tangentEdgeMode; // default: phantom

  // Part Appearance
  final bool useOnshapeCadColor; // default true (Onshape slate steel-blue 0x70A5C2 / 0xFF6C9DC6)
  final bool hiddenEdgesVisible; // default false
  final bool highlightBoundaryEdges; // default false (highlights open/laminar sheet edges in red)
  final Color boundaryEdgeColor; // default 0xFFEF4444 (red)
  final double meshLineWidth; // 0.5 px to 5.0 px, default 1.2 px
  final double transparencyLevel; // 0.05 to 0.95, default 0.35 (opacity for translucent / isolated parts)

  // Studio Lighting Controls (Global lighting addition, removal, and spherical roaming)
  final double lightAzimuthDeg; // 0 deg to 360 deg, default 45 deg
  final double lightElevationDeg; // 10 deg to 90 deg, default 55 deg
  final double keyLightIntensity; // 0.0 to 3.0, default 1.45
  final bool hasSecondaryLight; // toggle secondary fill light, default true
  final bool hasBackLight; // toggle rim/back light, default false

  // Welding Display Settings (SS1 / SS2)
  final bool showWeldOverlay; // default true (translucent overlaid color on welds)
  final Color weldOverlayColor; // default 0xD9F59E0B (amber gold)

  // PBR / Shader Material Settings (Hot-Dip Galvanized, Pre-Galvanized, Plastic, Chrome, etc.)
  final CadMaterialSettings materialSettings;

  // New Pro CAD Visual Polish Settings (Part C)
  final CadLightingPreset lightingPreset; // default: CadLightingPreset.onshapeStudio
  final double cavityStrength;            // 0% to 100%, default 65% (darkens inner folds, brightens convex edges)
  final bool silhouetteEdgeBoost;         // default true (renders outer contour edges 1.35x thicker than inner creases)
  final bool showGroundShadow;            // default true (renders soft contact shadow plane on Z = 0 floor)
  final bool screenSpaceEdgeAntiAliasing; // default true (hardware MSAA vector edge smoothing pass)

  const OnshapeGraphicsPreferences({
    this.ambientOcclusion = 65.0,
    this.fieldOfView = 46.0,
    this.antiAliasingQuality = AntiAliasingQuality.high,
    this.lineWidth = 1.35,
    this.shininess = 68.0,
    this.specularColor = const Color(0xFFFFFFFF),
    this.sectionInterferenceColor = const Color(0xFF4CAF50),
    this.phantomTangentEdgeWidth = 0.8,
    this.phantomTangentEdgeColor = const Color(0xFF212121),
    this.tangentEdgeMode = OnshapeTangentEdgeMode.phantom,
    this.useOnshapeCadColor = true,
    this.hiddenEdgesVisible = false,
    this.highlightBoundaryEdges = false,
    this.boundaryEdgeColor = const Color(0xFFEF4444),
    this.meshLineWidth = 1.2,
    this.transparencyLevel = 0.35,
    this.lightAzimuthDeg = 45.0,
    this.lightElevationDeg = 55.0,
    this.keyLightIntensity = 1.45,
    this.hasSecondaryLight = true,
    this.hasBackLight = false,
    this.showWeldOverlay = true,
    this.weldOverlayColor = const Color(0xD9F59E0B),
    this.materialSettings = const CadMaterialSettings(),
    this.lightingPreset = CadLightingPreset.onshapeStudio,
    this.cavityStrength = 65.0,
    this.silhouetteEdgeBoost = true,
    this.showGroundShadow = true,
    this.screenSpaceEdgeAntiAliasing = true,
  });

  OnshapeGraphicsPreferences copyWith({
    double? ambientOcclusion,
    double? fieldOfView,
    AntiAliasingQuality? antiAliasingQuality,
    double? lineWidth,
    double? shininess,
    Color? specularColor,
    Color? sectionInterferenceColor,
    double? phantomTangentEdgeWidth,
    Color? phantomTangentEdgeColor,
    OnshapeTangentEdgeMode? tangentEdgeMode,
    bool? useOnshapeCadColor,
    bool? hiddenEdgesVisible,
    bool? highlightBoundaryEdges,
    Color? boundaryEdgeColor,
    double? meshLineWidth,
    double? transparencyLevel,
    double? lightAzimuthDeg,
    double? lightElevationDeg,
    double? keyLightIntensity,
    bool? hasSecondaryLight,
    bool? hasBackLight,
    bool? showWeldOverlay,
    Color? weldOverlayColor,
    CadMaterialSettings? materialSettings,
    CadLightingPreset? lightingPreset,
    double? cavityStrength,
    bool? silhouetteEdgeBoost,
    bool? showGroundShadow,
    bool? screenSpaceEdgeAntiAliasing,
  }) {
    return OnshapeGraphicsPreferences(
      ambientOcclusion: ambientOcclusion ?? this.ambientOcclusion,
      fieldOfView: fieldOfView ?? this.fieldOfView,
      antiAliasingQuality: antiAliasingQuality ?? this.antiAliasingQuality,
      lineWidth: lineWidth ?? this.lineWidth,
      shininess: shininess ?? this.shininess,
      specularColor: specularColor ?? this.specularColor,
      sectionInterferenceColor: sectionInterferenceColor ?? this.sectionInterferenceColor,
      phantomTangentEdgeWidth: phantomTangentEdgeWidth ?? this.phantomTangentEdgeWidth,
      phantomTangentEdgeColor: phantomTangentEdgeColor ?? this.phantomTangentEdgeColor,
      tangentEdgeMode: tangentEdgeMode ?? this.tangentEdgeMode,
      useOnshapeCadColor: useOnshapeCadColor ?? this.useOnshapeCadColor,
      hiddenEdgesVisible: hiddenEdgesVisible ?? this.hiddenEdgesVisible,
      highlightBoundaryEdges: highlightBoundaryEdges ?? this.highlightBoundaryEdges,
      boundaryEdgeColor: boundaryEdgeColor ?? this.boundaryEdgeColor,
      meshLineWidth: meshLineWidth ?? this.meshLineWidth,
      transparencyLevel: transparencyLevel ?? this.transparencyLevel,
      lightAzimuthDeg: lightAzimuthDeg ?? this.lightAzimuthDeg,
      lightElevationDeg: lightElevationDeg ?? this.lightElevationDeg,
      keyLightIntensity: keyLightIntensity ?? this.keyLightIntensity,
      hasSecondaryLight: hasSecondaryLight ?? this.hasSecondaryLight,
      hasBackLight: hasBackLight ?? this.hasBackLight,
      showWeldOverlay: showWeldOverlay ?? this.showWeldOverlay,
      weldOverlayColor: weldOverlayColor ?? this.weldOverlayColor,
      materialSettings: materialSettings ?? this.materialSettings,
      lightingPreset: lightingPreset ?? this.lightingPreset,
      cavityStrength: cavityStrength ?? this.cavityStrength,
      silhouetteEdgeBoost: silhouetteEdgeBoost ?? this.silhouetteEdgeBoost,
      showGroundShadow: showGroundShadow ?? this.showGroundShadow,
      screenSpaceEdgeAntiAliasing: screenSpaceEdgeAntiAliasing ?? this.screenSpaceEdgeAntiAliasing,
    );
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is OnshapeGraphicsPreferences &&
        other.ambientOcclusion == ambientOcclusion &&
        other.fieldOfView == fieldOfView &&
        other.antiAliasingQuality == antiAliasingQuality &&
        other.lineWidth == lineWidth &&
        other.shininess == shininess &&
        other.specularColor == specularColor &&
        other.sectionInterferenceColor == sectionInterferenceColor &&
        other.phantomTangentEdgeWidth == phantomTangentEdgeWidth &&
        other.phantomTangentEdgeColor == phantomTangentEdgeColor &&
        other.tangentEdgeMode == tangentEdgeMode &&
        other.useOnshapeCadColor == useOnshapeCadColor &&
        other.hiddenEdgesVisible == hiddenEdgesVisible &&
        other.highlightBoundaryEdges == highlightBoundaryEdges &&
        other.boundaryEdgeColor == boundaryEdgeColor &&
        other.meshLineWidth == meshLineWidth &&
        other.transparencyLevel == transparencyLevel &&
        other.lightAzimuthDeg == lightAzimuthDeg &&
        other.lightElevationDeg == lightElevationDeg &&
        other.keyLightIntensity == keyLightIntensity &&
        other.hasSecondaryLight == hasSecondaryLight &&
        other.hasBackLight == hasBackLight &&
        other.materialSettings == materialSettings &&
        other.lightingPreset == lightingPreset &&
        other.cavityStrength == cavityStrength &&
        other.silhouetteEdgeBoost == silhouetteEdgeBoost &&
        other.showGroundShadow == showGroundShadow &&
        other.screenSpaceEdgeAntiAliasing == screenSpaceEdgeAntiAliasing;
  }

  @override
  int get hashCode => Object.hashAll([
        ambientOcclusion,
        fieldOfView,
        antiAliasingQuality,
        lineWidth,
        shininess,
        specularColor,
        sectionInterferenceColor,
        phantomTangentEdgeWidth,
        phantomTangentEdgeColor,
        tangentEdgeMode,
        useOnshapeCadColor,
        hiddenEdgesVisible,
        highlightBoundaryEdges,
        boundaryEdgeColor,
        meshLineWidth,
        transparencyLevel,
        lightAzimuthDeg,
        lightElevationDeg,
        keyLightIntensity,
        hasSecondaryLight,
        hasBackLight,
        materialSettings,
        lightingPreset,
        cavityStrength,
        silhouetteEdgeBoost,
        showGroundShadow,
        screenSpaceEdgeAntiAliasing,
      ]);
}

/// Axis orientations for Onshape-style dynamic section plane.
enum SectionPlaneAxis { xy, yz, zx }

/// Configuration for Onshape dynamic 3D Section View tool.
class SectionViewConfig {
  final bool isEnabled;
  final SectionPlaneAxis axis;
  final double distanceOffsetMm;
  final bool flipNormal;

  const SectionViewConfig({
    this.isEnabled = false,
    this.axis = SectionPlaneAxis.yz,
    this.distanceOffsetMm = 0.0,
    this.flipNormal = false,
  });

  SectionViewConfig copyWith({
    bool? isEnabled,
    SectionPlaneAxis? axis,
    double? distanceOffsetMm,
    bool? flipNormal,
  }) {
    return SectionViewConfig(
      isEnabled: isEnabled ?? this.isEnabled,
      axis: axis ?? this.axis,
      distanceOffsetMm: distanceOffsetMm ?? this.distanceOffsetMm,
      flipNormal: flipNormal ?? this.flipNormal,
    );
  }
}

/// Named camera orientation snapshot.
class NamedCadView {
  final String name;
  final Cad3dCameraState state;

  const NamedCadView({required this.name, required this.state});

  Map<String, dynamic> toJson() => {
        'name': name,
        'state': state.toJson(),
      };

  factory NamedCadView.fromJson(Map<String, dynamic> json) {
    return NamedCadView(
      name: json['name'] as String? ?? 'Named View',
      state: Cad3dCameraState.fromJson(Map<String, dynamic>.from(json['state'] as Map? ?? {})),
    );
  }
}

/// Viewport workspace presentation layout for responsive desktop CAD screens.
enum ViewportLayoutMode {
  split('Split (50/50)', Icons.vertical_split_rounded),
  canvas2D('2D Flat Blank', Icons.crop_square_rounded),
  viewport3D('3D Folded Mesh', Icons.view_in_ar_rounded);

  final String label;
  final IconData icon;
  const ViewportLayoutMode(this.label, this.icon);

  bool get isSplit => this == ViewportLayoutMode.split;
  bool get is2DOnly => this == ViewportLayoutMode.canvas2D;
  bool get is3DOnly => this == ViewportLayoutMode.viewport3D;
}

/// Workspace UI scaling density mode for desktop displays & laptops.
enum UiDensityMode {
  auto('Auto (Laptop Detect)', Icons.laptop_mac_rounded),
  compact('Compact (85%)', Icons.zoom_in_map_rounded),
  standard('Standard (100%)', Icons.zoom_out_map_rounded);

  final String label;
  final IconData icon;
  const UiDensityMode(this.label, this.icon);

  bool get isAuto => this == UiDensityMode.auto;
  bool get isCompact => this == UiDensityMode.compact;
  bool get isStandard => this == UiDensityMode.standard;
}

/// Docking position for the CAD action ribbon and tool palette.
enum ToolbarDockPosition {
  top('Top (Horizontal)', Icons.vertical_align_top),
  left('Left (Vertical)', Icons.align_horizontal_left),
  right('Right (Vertical)', Icons.align_horizontal_right),
  detached('Detached (Floating)', Icons.open_in_new);

  final String label;
  final IconData icon;
  const ToolbarDockPosition(this.label, this.icon);

  bool get isTop => this == ToolbarDockPosition.top;
  bool get isLeft => this == ToolbarDockPosition.left;
  bool get isRight => this == ToolbarDockPosition.right;
  bool get isDetached => this == ToolbarDockPosition.detached;
  bool get isVertical => this == ToolbarDockPosition.left || this == ToolbarDockPosition.right;
}



