// Top-Right Status Pill (OSHA/ISO Compliance & Cut List / BOM)
// Modularized for TruFold MVVM Architecture

import 'package:flutter/material.dart';
import 'package:trufold_studio/assembly_studio/viewmodels/assembly_studio_viewmodel.dart';

class AssemblyViewportStatusPill extends StatelessWidget {
  final AssemblyStudioViewModel viewModel;
  final VoidCallback onShowComplianceAuditDialog;
  final VoidCallback onShowBomDialog;

  const AssemblyViewportStatusPill({
    super.key,
    required this.viewModel,
    required this.onShowComplianceAuditDialog,
    required this.onShowBomDialog,
  });

  @override
  Widget build(BuildContext context) {
    final report = viewModel.evaluateLadderCompliance();

    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        // Active 3D Render Engine Status Pill (Impeller GPU 120 FPS)
        Tooltip(
          message: '3D Render Engine: Flutter GPU (Impeller)\nHardware-accelerated 120 FPS PBR rendering active.',
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: const Color(0xFF10B981),
                width: 1.2,
              ),
              boxShadow: const [
                BoxShadow(color: Color(0x15000000), blurRadius: 8, offset: Offset(0, 2)),
              ],
            ),
            child: const Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  Icons.speed_rounded,
                  color: Color(0xFF059669),
                  size: 14,
                ),
                SizedBox(width: 5),
                Text(
                  '⚡ GPU (Impeller 120 FPS)',
                  style: TextStyle(
                    fontSize: 10.5,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF047857),
                    letterSpacing: 0.2,
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(width: 8),
        // Live OSHA / ISO Compliance Badge
        InkWell(
          borderRadius: BorderRadius.circular(20),
          onTap: onShowComplianceAuditDialog,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: report.badgeColor.withValues(alpha: 0.95),
                width: 1.2,
              ),
              boxShadow: const [
                BoxShadow(
                  color: Color(0x15000000),
                  blurRadius: 8,
                  offset: Offset(0, 2),
                ),
              ],
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  report.isCompliant ? Icons.verified_rounded : Icons.warning_amber_rounded,
                  color: report.badgeColor,
                  size: 15,
                ),
                const SizedBox(width: 6),
                Text(
                  report.badgeLabel,
                  style: TextStyle(
                    fontSize: 10.5,
                    fontWeight: FontWeight.bold,
                    color: report.badgeColor,
                    letterSpacing: 0.3,
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(width: 8),

        // BOM & Cut List Pill Button
        InkWell(
          borderRadius: BorderRadius.circular(20),
          onTap: onShowBomDialog,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: const Color(0xFF0076CE).withValues(alpha: 0.8),
                width: 1.0,
              ),
              boxShadow: const [
                BoxShadow(
                  color: Color(0x15000000),
                  blurRadius: 8,
                  offset: Offset(0, 2),
                ),
              ],
            ),
            child: const Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  Icons.inventory_2_rounded,
                  color: Color(0xFF0076CE),
                  size: 14,
                ),
                SizedBox(width: 5),
                Text(
                  'Cut List / BOM',
                  style: TextStyle(
                    fontSize: 10.5,
                    fontWeight: FontWeight.w700,
                    color: Color(0xFF0076CE),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
